import java.util.Scanner;

public class example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		System.out.print("�� ������ �Է��ϼ���>>");
		int a = s.nextInt();
		int b = s.nextInt();
		
		System.out.println(a + "+" + b + "�� " + (a+b));
		
	}

}
