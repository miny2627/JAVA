import java.util.Scanner;

public class example {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		System.out.print("������ �Է��ϼ���>>");
		String grade = s.next();
		
		switch(grade){
			case "A": 
			case "B":
				System.out.println("Excellent");
				break;
			case "C": 
			case "D":
				System.out.println("Good");
				break;
			case "F":
				System.out.println("Bye");
				break;
		}
	}
}